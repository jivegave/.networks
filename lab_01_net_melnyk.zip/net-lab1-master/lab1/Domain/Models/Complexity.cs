﻿namespace lab1.Domain.Models;

public enum Complexity
{
    None,
    Minutes,
    Hours,
    Days,
    Weeks
}