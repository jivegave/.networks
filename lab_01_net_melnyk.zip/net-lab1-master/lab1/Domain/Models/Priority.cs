﻿namespace lab1.Domain.Models;

public enum Priority
{
    None,
    Low,
    Medium,
    High,
    Urgent
}